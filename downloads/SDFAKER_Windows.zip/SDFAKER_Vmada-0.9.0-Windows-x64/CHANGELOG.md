# Changelog — SDFAKER Vmada

## 0.9.0 — 2026-11-08
- Ajout d'une pile Undo/Redo avec `Ctrl+Z`, `Ctrl+Y` et `Ctrl+Shift+Z`, menu Fanovana et boutons dédiés dans la barre du viewport.
- Les transactions de souris et clavier sont regroupées : un glisser-déposer complet n'ajoute qu'une seule étape d'annulation.
- L'historique couvre les modifications persistantes de la scène : objets, transformations, topologie, modificateurs, keyframes et paramètres de scène suivis.
- Limitation de l'historique à 32 étapes et 64 Mo pour préserver les machines à 4 Go de RAM ; caches de rendu exclus des snapshots.
- Ajout du copier/coller/couper d'objet (`Ctrl+C` / `Ctrl+V` / `Ctrl+X`) et amélioration de la duplication (`Shift+D`).
- Ajout de boutons Undo/Redo avec icônes et compteur d'historique dans la barre d'état.
- Mise à jour de l'aide intégrée et du guide des raccourcis ; les raccourcis G/R/S ne réagissent plus aux combinaisons Ctrl/Alt/Shift.

## 0.8.0 — 2026-11-08
- Amélioration du modificateur Mirror : fusion des sommets superposés et suppression des triangles strictement dupliqués.
- Application d'un plafond géométrique pendant la génération des modificateurs Array, Wireframe, Solidify et Bevel, afin de réduire les pics mémoire.
- Ajout d'icônes dédiées Sauvegarder et Supprimer dans la barre d'outils du viewport.
- Renforcement de la documentation des limites de l'animation et des modificateurs.

## 0.7.0 — 2026-11-08
- Ajout de la sauvegarde manuelle `.svmp` : Ctrl+S, Ctrl+Shift+S, Ctrl+O et bouton visible.
- Sérialisation des objets, maillages, transformations, visibilité, modificateurs et keyframes.
- Ajout d'une Timeline dockée avec lecture/pause/arrêt, curseur de frame, plage de lecture et marqueurs de keyframes.
- Ajout de keyframes de position, rotation et échelle avec interpolation linéaire.
- Ajout d'une suppression d'objet plus claire : Delete/X, Outliner, menu et bouton de viewport.
- Wireframe converti en géométrie de barres, ce qui permet aussi de l'appliquer au maillage.
- Ajout de l'application individuelle des modificateurs dans l'ordre de la pile.
- Mise en cache de l'évaluation des modificateurs pour éviter de les recalculer à chaque frame.
- Conservation de la sauvegarde strictement manuelle : aucun autosave.

## 0.6.0
- Mode Objet et Mode Édition du maillage.
- Primitives de base et outils de sélection de sommets/arêtes/faces.
- Première pile de modificateurs.

## 0.4.0
- Barre d'onglets de type navigateur.
- Espace de travail 3D dockable.
