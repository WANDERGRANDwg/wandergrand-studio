# Third-party components

This prototype bundles the source files required to build the interface:

- Dear ImGui Docking, version string `1.93.1 WIP`, from the archive supplied for this project. Its license is in `external/imgui/LICENSE.txt`.
- ImGuizmo, version string `1.92.5 WIP`, from the archive supplied for this project. Its license is in `external/ImGuizmo/LICENSE`.

Only the core Dear ImGui files and SDL2/OpenGL3 backends needed by this Linux prototype are included. Unused backends, examples and image documentation were left out to keep the source archive small.
