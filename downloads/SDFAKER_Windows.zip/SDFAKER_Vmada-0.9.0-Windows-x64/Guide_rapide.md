# Guide rapide — SDFAKER Vmada 0.9.0

## Enregistrer puis rouvrir un projet

1. Clique sur **Tehirizo** dans la barre d'outils ou utilise `Ctrl+S`.
2. Au premier enregistrement, saisis un nom tel que `MonJeu.svmp` dans la fenêtre.
3. Pour continuer plus tard, fais `Ctrl+O` et saisis le même chemin.
4. La sauvegarde est strictement manuelle : rien n'est écrit automatiquement.

## Ajouter et supprimer des objets

- `Ampidiro > Harato fototra` permet de créer un cube, un plan, une sphère, un cylindre, un cône, une pyramide, un tore, un cercle ou une grille.
- Sélectionne l'objet dans la vue 3D ou l'Outliner.
- Utilise le bouton **Fafao**, la commande `Zavatra > Fafao ny zavatra`, ou la touche `Delete` / `X` en Mode Objet.
- En Mode Édition (`Tab`), `Delete` / `X` supprime les éléments du maillage sélectionnés, pas l'objet entier.

## Vérifier les modificateurs

1. Sélectionne un objet.
2. Clique sur l'icône des modificateurs dans la colonne de l'inspecteur.
3. Clique sur **+ Ampio Modifier** et choisis un modificateur.
4. Le résultat évalué apparaît dans la vue 3D. Les valeurs modifiées sont prises en compte automatiquement.
5. Le nombre de triangles de base et de sortie est indiqué sous la pile.
6. **Ampiharo** valide le modificateur choisi et ceux qui le précèdent dans la pile. **Esory** le retire sans modifier le maillage original.

Note : Mirror ne change pas nécessairement l'apparence d'un cube complet déjà symétrique. Wireframe crée une vraie géométrie de petites barres et son application est conservée.

## Créer une animation simple

1. Sélectionne un objet et garde le playhead à `Sary 1`.
2. Place l'objet à sa position de départ et clique sur **+ Lakile** (ou appuie sur `I` dans le viewport en Mode Objet).
3. Déplace le curseur de frame, par exemple à `Sary 60`.
4. Déplace, tourne ou redimensionne l'objet.
5. Clique de nouveau sur **+ Lakile**.
6. Clique sur **Alefaso** pour lire l'animation. L'application interpole position, rotation et échelle entre les deux keyframes.
7. `Ajanony` revient à la frame 1. Le bouton **Fafao lakile** efface la keyframe de la frame courante ; **Fafao daholo** efface les keyframes de l'objet.

L'animation actuelle concerne les transformations d'objets. Elle n'anime pas encore les os, les personnages, les matériaux ou les paramètres de modificateur.


## Annuler, rétablir, copier et dupliquer

- `Ctrl+Z` annule la dernière opération de scène.
- `Ctrl+Y` ou `Ctrl+Shift+Z` rétablit l'opération annulée.
- Les boutons Undo / Redo sont disponibles dans l'en-tête du viewport ; le menu `Fanovana` contient les mêmes commandes.
- Une manipulation glissée (gizmo ou curseur) est regroupée en une seule entrée d'historique.
- `Ctrl+C` copie l'objet sélectionné dans le presse-papiers interne de SDFAKER ; `Ctrl+V` colle une copie ; `Ctrl+X` coupe (copie puis supprime) l'objet.
- `Shift+D` duplique directement l'objet sélectionné.
- L'historique est plafonné à 32 étapes / 64 Mo. Si un snapshot de scène dépasse cette limite, SDFAKER affiche un message et ne l'ajoute pas à l'historique.

## Raccourcis principaux

| Raccourci | Action |
|---|---|
| `Ctrl+N` | Nouveau projet |
| `Ctrl+O` | Ouvrir un projet `.svmp` |
| `Ctrl+S` | Enregistrer |
| `Ctrl+Shift+S` | Enregistrer sous |
| `Ctrl+Z` | Annuler |
| `Ctrl+Y` / `Ctrl+Shift+Z` | Rétablir |
| `Ctrl+C` / `Ctrl+V` / `Ctrl+X` | Copier / coller / couper l'objet |
| `Shift+D` | Dupliquer |
| `Delete` / `X` | Supprimer l'objet ou la sélection du maillage |
| `Tab` | Mode Objet / Édition |
| `G` / `R` / `S` | Déplacer / tourner / échelle |
| `1` / `2` / `3` | Sommets / arêtes / faces en Mode Édition |
| `A` / `Alt+A` | Tout sélectionner / désélectionner en Mode Édition |
| `E` / `I` / `F` | Extrusion / Inset / Fill |
| `Shift+N` | Recalculer les normales |
| `I` | Insérer une keyframe en Mode Objet |
| `Espace` | Lecture / pause de l'animation lorsque le viewport est actif |
| `F1` | Afficher / masquer l'aide |
| `Home` | Recentrer la vue sur l'objet sélectionné |
| `Pavé numérique 1 / 3 / 7` | Vues face / droite / dessus |
| `Pavé numérique 5` | Perspective / orthographique |

Note : `Ctrl+C` / `Ctrl+V` / `Ctrl+X` agissent sur un objet entier, pas sur les éléments de maillage sélectionnés. Les changements de sélection seule, de préférence d'interface et les mouvements de caméra ne sont pas inclus dans l'historique de scène.
