#!/bin/sh
# Lanceur SDFAKER Vmada — se place dans le dossier du package puis démarre le programme.
cd "$(dirname "$0")" || exit 1
exec ./sdfaker_vmada "$@"
